using UnityEngine;
using UnityEngine.InputSystem;

public class PickingUpSystem : MonoBehaviour
{
    public InputSystemActions controls;
    void Awake(){
        controls = InputScript.InputSysAc;
        controls.Player.PickUp.performed += ctx => PickUpMethod(ctx);
    }

    void PickUpMethod(InputAction.CallbackContext ctx)
    {
        if(PlayerNearCheck.ToolToPickUp != null)
        {
            Destroy(PlayerNearCheck.ToolToPickUp);
        }
    }
}
