using UnityEngine;

public class WinningHit : MonoBehaviour
{
    public GameObject WinningUI;
    public GameObject TimeUI;
    public bool hasWon = false;

    void OnTriggerEnter(Collider collider){
        WinningUI.SetActive(true);
        TimeUI.SetActive(false);
        InputScript.InputSysAc.Disable();
        hasWon = true;
    }
}
