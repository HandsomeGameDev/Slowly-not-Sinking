using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class CameraProcessing : MonoBehaviour
{
    public Volume vol;
    private Vignette vign;
    private ColorAdjustments coladj;
    public int rColorAdj = 0;
    public int gColorAdj = 0;
    public int bColorAdj = 0;
    private float depth = 0.0f;
    public bool underWater = false;
    public VolumeProfile surfacePP;
    public VolumeProfile underwaterPP;

    void Start()
    {
        RenderSettings.fog = true;
        vol.profile = underwaterPP;
    }

    void FixedUpdate()
    {
        depth = transform.position.y;

        if (vol.profile.TryGet(out vign)){}
        if(vol.profile.TryGet(out coladj)){}
        vign.intensity.value = 0.75f * (Mathf.Max(-70.0f, depth)/ -70.0f);
        rColorAdj = (int)Mathf.Lerp(85, 40, Mathf.Max(-70.0f, depth)/-70.0f);
        gColorAdj = (int)Mathf.Lerp(100, 50, Mathf.Max(-70.0f, depth)/-70.0f);
        bColorAdj = (int)Mathf.Lerp(115, 60, Mathf.Max(-70.0f, depth)/-70.0f);
        coladj.colorFilter.value = new Color32((byte)rColorAdj, (byte)gColorAdj, (byte)bColorAdj, 255);
    }
}
