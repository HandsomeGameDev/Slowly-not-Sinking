using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody))] // This gives the object the rigid body component if it doesn't have one
public class SwimmingMovement : MonoBehaviour
{
    public Transform direction; // This dictates what the movement is realitive to whether that be a camera or the player
    public InputSystemActions controls; // this is the input system for the player

    [Header("Swimming")]
    public float speed = 2.5f; // The speed you want to be able to swim at
    public float acceleration = 20.0f; // How fast you can chhange your speed
    public float realitiveVerticalLimit = 0.85f;

    private Rigidbody rbPlayer; // The rigidbody component for your player so you can move them and find velocity
    private Vector2 horizontalInput; // The variable that tracks your input for the x and z direction
    private float verticalInput; // tracks your input for the veritcal direction

    void Awake()
    {
        rbPlayer = GetComponent<Rigidbody>(); // Grabs the Rigidbody componet for you

        controls = InputScript.InputSysAc; // This Grabs the input system script

        // These grab your input values from the input system and sets the input variables accordingly(for this to work jump must be an axis)
        controls.Player.Move.performed += ctx => horizontalInput = ctx.ReadValue<Vector2>();
        controls.Player.Move.canceled += ctx => horizontalInput = Vector2.zero;
        controls.Player.Jump.performed += ctx => verticalInput = ctx.ReadValue<float>();
        controls.Player.Jump.canceled += ctx => verticalInput = 0.0f;

    }



    float ClosestClamp(float numberToClamp, float clampMagnitude)
    {
        float min = Mathf.Min(-clampMagnitude, clampMagnitude);
        float max = Mathf.Max(-clampMagnitude, clampMagnitude);
        return Mathf.Clamp(numberToClamp, min, max);
    }


    void FixedUpdate()
    {
        Vector3 moveDirectionX = direction.right * horizontalInput.x; // This multiplies your right/left input by the right direction of the camera
        Vector3 moveDirectionY = Vector3.up * verticalInput; // This multiplies the up direction by the universal up diretction so up doesn't flip you over, and so that you don't get turned around
        Vector3 moveDirectionZ = direction.forward * horizontalInput.y; // This multiplies your forward/back input by the forward direction of the camera

        Vector3 rawTargetDirection = moveDirectionX + moveDirectionY + moveDirectionZ; // This combinds all of the directions then mulitplies
        rawTargetDirection.y *= realitiveVerticalLimit; // this mulitplies the y direction by realitiveVerticalLimit so swimming in the y direction is slower than the horizontal direction

        Vector3 normalizedTargetDirection = Vector3.ClampMagnitude(rawTargetDirection, 1.0f);

        Vector3 targetVelocity = normalizedTargetDirection * speed; // this multiplies your movement direction to find the velocity you want to go

        Vector3 velocityChange = targetVelocity - rbPlayer.linearVelocity; // this finds the difference between the velocity you want to go and the velocity you are currently going

        velocityChange.x = ClosestClamp(velocityChange.x, targetVelocity.x);
        velocityChange.y = ClosestClamp(velocityChange.y, targetVelocity.y);
        velocityChange.z = ClosestClamp(velocityChange.z, targetVelocity.z);

        Vector3 velocityChangeClamped = Vector3.ClampMagnitude(velocityChange, acceleration * Time.fixedDeltaTime); // This clamps the amount of force you can give yourself so you don't cancel out physics interaction

        rbPlayer.AddForce(velocityChangeClamped, ForceMode.VelocityChange); //this finally adds the force and multiplies it times your mass so you go the same speed no matter how much you weigh

    }
}
